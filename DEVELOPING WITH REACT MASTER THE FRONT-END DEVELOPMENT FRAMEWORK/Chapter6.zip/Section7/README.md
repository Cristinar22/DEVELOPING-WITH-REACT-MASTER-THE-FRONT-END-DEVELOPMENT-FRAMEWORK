# Recipe Vault Hands-On Project

Folder structure:
/src
  /pages
    Home.jsx
    Recipes.jsx
    RecipeDetail.jsx
    EditRecipe.jsx
  /layouts
    MainLayout.jsx
  /components
    Skeleton.jsx
  App.jsx
  index.jsx
  data/recipes.json
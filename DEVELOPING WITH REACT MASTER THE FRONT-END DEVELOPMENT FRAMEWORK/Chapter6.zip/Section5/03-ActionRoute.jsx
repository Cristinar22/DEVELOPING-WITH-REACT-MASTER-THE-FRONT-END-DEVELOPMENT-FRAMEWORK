<Route
  path="recipes/:id/edit"
  element={<EditRecipe />}
  action={async ({ request }) => {
    const data = await request.formData();
    // ...save logic
    return redirect(`/recipes/${data.get("id")}`);
  }}
/>
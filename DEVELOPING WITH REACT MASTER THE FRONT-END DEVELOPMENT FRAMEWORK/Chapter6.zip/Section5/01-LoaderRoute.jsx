<Route
  path="recipes/:id"
  element={<RecipeDetail />}
  loader={async ({ params }) => {
    return fetch(`/api/recipes/${params.id}`).then(res => res.json());
  }}
/>
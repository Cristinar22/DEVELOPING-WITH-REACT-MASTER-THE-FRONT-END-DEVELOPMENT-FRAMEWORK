import { useLoaderData } from "react-router-dom";
export default function RecipeDetail() {
  const recipe = useLoaderData();
  // ...
}
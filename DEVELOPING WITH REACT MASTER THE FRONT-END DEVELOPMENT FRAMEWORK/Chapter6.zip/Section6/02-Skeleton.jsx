export default function Skeleton() {
  return (
    <div className="skeleton">
      Loading...
    </div>
  );
}
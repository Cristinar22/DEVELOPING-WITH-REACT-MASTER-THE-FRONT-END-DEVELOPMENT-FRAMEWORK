import { lazy, Suspense } from "react";
const EditRecipe = lazy(() => import("./pages/EditRecipe"));

<Route
  path="recipes/:id/edit"
  element={
    <Suspense fallback={<Skeleton />}>
      <EditRecipe />
    </Suspense>
  }
/>
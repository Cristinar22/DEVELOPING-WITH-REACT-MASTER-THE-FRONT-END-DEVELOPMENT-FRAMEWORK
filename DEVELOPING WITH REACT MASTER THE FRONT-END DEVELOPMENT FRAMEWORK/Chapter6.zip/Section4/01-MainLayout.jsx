import { Outlet } from "react-router-dom";
export default function MainLayout() {
  return (
    <div>
      <header>My Recipe Vault</header>
      <main><Outlet /></main>
    </div>
  );
}
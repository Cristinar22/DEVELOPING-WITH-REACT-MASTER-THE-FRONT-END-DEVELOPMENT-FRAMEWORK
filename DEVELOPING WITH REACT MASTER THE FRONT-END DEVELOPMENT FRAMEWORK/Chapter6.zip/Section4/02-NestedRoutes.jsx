<Routes>
  <Route path="/" element={<MainLayout />}>
    <Route index element={<Home />} />
    <Route path="recipes" element={<Recipes />} />
    <Route path="recipes/:id" element={<RecipeDetail />} />
    <Route path="recipes/:id/edit" element={<EditRecipe />} />
  </Route>
</Routes>
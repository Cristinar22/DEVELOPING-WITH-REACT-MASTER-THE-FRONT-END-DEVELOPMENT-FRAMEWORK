bash

pnpm add react-router-dom

import { useNavigate } from "react-router-dom";
function EditRecipe() {
  const navigate = useNavigate();
  // ... form code
  function handleSubmit() {
    // save logic...
    navigate("/recipes");
  }
}
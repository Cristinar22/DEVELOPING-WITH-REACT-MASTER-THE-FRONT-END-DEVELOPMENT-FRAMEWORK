import { useParams, Link } from "react-router-dom";
import recipes from "../data/recipes.json";

export default function RecipeDetail() {
  const { id } = useParams();
  const recipe = recipes.find(r => r.id === id);

  if (!recipe) return <div>Not found</div>;

  return (
    <article>
      <h1>{recipe.title}</h1>
      <p>{recipe.description}</p>
      <Link to="/recipes">Back to all recipes</Link>
    </article>
);
import { Link } from "react-router-dom";
import recipes from "../data/recipes.json";

export default function Recipes() {
  return (
    <section>
      <h1>All Recipes</h1>
      <ul>
        {recipes.map(r => (
          <li key={r.id}>
            <Link to={`/recipes/${r.id}`}>{r.title}</Link>
          </li>
        ))}
      </ul>
    </section>
);
import { BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";
const data = [ /* ... */ ];

export default function RecipeStats() {
  return (
    <BarChart width={300} height={200} data={data}>
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Bar dataKey="timesCooked" fill="#8884d8" />
    </BarChart>
);
import { useState, useEffect } from "react";
import { useDebounce, useDocumentTitle } from "./useDebounce";

function FeedbackForm() {
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const debouncedMessage = useDebounce(message, 300);

  useEffect(() => {
    // Auto-save or validate debouncedMessage
  }, [debouncedMessage]);

  useDocumentTitle(submitted ? "Thank You!" : "Feedback Form");

  return (
    <div>
      <textarea value={message} onChange={e => setMessage(e.target.value)} />
      <button onClick={() => setSubmitted(true)}>Submit</button>
    </div>
  );
}

export default FeedbackForm;
import { useEffect } from "react";

export function useDocumentTitle(title, options = {}) {
  useEffect(() => {
    const prev = document.title;
    document.title = title;
    return () => {
      if (options.restore) document.title = prev;
    };
  }, [title]);
}
import { useEffect } from "react";

function Modal({ closeModal }) {
  useEffect(() => {
    function handleEsc(e) {
      if (e.key === "Escape") closeModal();
    }
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [closeModal]);

  return <div>Modal Content</div>;
}

export default Modal;
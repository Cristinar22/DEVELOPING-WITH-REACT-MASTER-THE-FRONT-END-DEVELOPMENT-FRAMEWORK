import { useEffect } from "react";

function IntervalComponent() {
  useEffect(() => {
    const id = setInterval(() => console.log("tick"), 1000);
    return () => clearInterval(id);
  }, []);

  return <div>Interval Running</div>;
}

export default IntervalComponent;
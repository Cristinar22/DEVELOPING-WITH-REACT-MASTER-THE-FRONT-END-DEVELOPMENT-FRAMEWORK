import { useCallback } from "react";

export const handleClick = useCallback(() => {
  doSomething();
}, []);
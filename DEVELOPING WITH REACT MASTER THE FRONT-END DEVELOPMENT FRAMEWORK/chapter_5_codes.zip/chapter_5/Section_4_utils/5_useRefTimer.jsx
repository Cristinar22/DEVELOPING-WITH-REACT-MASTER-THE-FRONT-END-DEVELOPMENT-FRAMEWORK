import { useRef } from "react";

export function TimerButton() {
  const timerId = useRef(null);

  function start() {
    timerId.current = setInterval(() => console.log("tick"), 1000);
  }
  function stop() {
    clearInterval(timerId.current);
  }

  return (
    <>
      <button onClick={start}>Start</button>
      <button onClick={stop}>Stop</button>
    </>
  );
}
import { useMemo } from "react";

export function FilteredList({ shipments }) {
  const filtered = useMemo(() => shipments.filter(isLate), [shipments]);
  return (
    <ul>
      {filtered.map(s => <li key={s.id}>{s.name}</li>)}
    </ul>
  );
}
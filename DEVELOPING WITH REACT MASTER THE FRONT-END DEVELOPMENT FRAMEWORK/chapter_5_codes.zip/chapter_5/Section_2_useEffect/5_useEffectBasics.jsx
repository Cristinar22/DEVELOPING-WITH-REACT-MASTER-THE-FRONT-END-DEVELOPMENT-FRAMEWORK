import { useEffect, useState } from "react";

function FeedbackForm() {
  const [message, setMessage] = useState("");

  useEffect(() => {
    console.log("Message changed:", message);
  }, [message]);

  return (
    <textarea value={message} onChange={e => setMessage(e.target.value)} />
  );
}

export default FeedbackForm;
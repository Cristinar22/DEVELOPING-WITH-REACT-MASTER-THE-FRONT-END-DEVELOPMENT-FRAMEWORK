#!/bin/bash
pnpm add web-vitals

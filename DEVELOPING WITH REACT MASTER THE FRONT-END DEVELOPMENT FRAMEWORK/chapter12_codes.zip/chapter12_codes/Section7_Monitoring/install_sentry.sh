#!/bin/bash
pnpm add @sentry/react @sentry/tracing

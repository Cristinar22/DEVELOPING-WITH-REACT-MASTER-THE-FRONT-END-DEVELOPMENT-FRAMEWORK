#!/bin/bash
pnpm add logrocket

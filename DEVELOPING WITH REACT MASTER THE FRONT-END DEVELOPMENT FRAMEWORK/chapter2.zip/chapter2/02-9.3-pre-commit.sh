#!/bin/bash
# Add pre-commit hook to run lint-staged
npx husky add .husky/pre-commit "pnpm lint-staged"

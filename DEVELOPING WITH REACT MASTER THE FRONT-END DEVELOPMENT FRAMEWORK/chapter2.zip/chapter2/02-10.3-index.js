#!/usr/bin/env node
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import { existsSync, cpSync, readFileSync, writeFileSync } from 'fs';
import { execa } from 'execa';
import chalk from 'chalk';

const [, , dest] = process.argv;
if (!dest) {
  console.log(chalk.red('❌  Project name required'));
  process.exit(1);
}
if (existsSync(dest)) {
  console.log(chalk.red('❌  Directory exists'));
  process.exit(1);
}

const __dirname = dirname(fileURLToPath(import.meta.url));
const tpl = resolve(__dirname, 'template');
cpSync(tpl, dest, { recursive: true });

const pkgJsonPath = resolve(dest, 'package.json');
const pkg = JSON.parse(readFileSync(pkgJsonPath));
pkg.name = dest;
writeFileSync(pkgJsonPath, JSON.stringify(pkg, null, 2));

console.log(chalk.green('✅  Files copied'));
await execa('pnpm', ['install'], { cwd: dest, stdio: 'inherit' });
console.log(chalk.blue(`\nNext:\n  cd ${dest}\n  pnpm dev`));

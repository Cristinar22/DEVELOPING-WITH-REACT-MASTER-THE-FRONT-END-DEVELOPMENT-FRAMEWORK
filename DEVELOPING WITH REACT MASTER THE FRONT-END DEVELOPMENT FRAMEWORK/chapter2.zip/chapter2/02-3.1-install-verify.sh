#!/bin/bash
# Install Node.js LTS 20.x and verify
echo "Downloading Node.js LTS installer..."
# Navigate to nodejs.org and download manually
echo "Installing Node.js..."
# After installation, verify versions
node -v   # Expect v20.x.x
npm -v    # Expect 10.x.x

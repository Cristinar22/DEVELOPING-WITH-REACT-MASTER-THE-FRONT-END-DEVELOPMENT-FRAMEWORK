#!/bin/bash
# Install and initialize Husky for Git hooks
pnpm add -D husky
npx husky install
echo 'pnpm husky install' >> package.json#scripts.postinstall

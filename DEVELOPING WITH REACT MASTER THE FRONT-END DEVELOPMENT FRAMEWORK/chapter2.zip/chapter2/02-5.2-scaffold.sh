#!/bin/bash
# Scaffolding a Vanilla React App with Vite and PNPM
pnpm create vite my-dashboard --template react
cd my-dashboard
pnpm install
pnpm dev  # Launch development server

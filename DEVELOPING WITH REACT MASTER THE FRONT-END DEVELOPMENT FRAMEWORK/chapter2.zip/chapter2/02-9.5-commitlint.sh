#!/bin/bash
# Add commit-msg hook to enforce conventional commits
pnpm add -D @commitlint/{config-conventional,cli}
npx husky add .husky/commit-msg "pnpm commitlint --edit $1"

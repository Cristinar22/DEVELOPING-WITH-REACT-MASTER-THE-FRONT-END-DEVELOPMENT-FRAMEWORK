// Visual regression snapshot example
await expect(page).toHaveScreenshot('onboarding-wizard.png');

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import OnboardingWizard from "./OnboardingWizard";

test("completes onboarding flow", async () => {
  render(<OnboardingWizard />);
  // Fill steps, click next, review, submit
  // Confirm data sent to mock server
  expect(await screen.findByText(/submitted/i)).toBeInTheDocument();
});

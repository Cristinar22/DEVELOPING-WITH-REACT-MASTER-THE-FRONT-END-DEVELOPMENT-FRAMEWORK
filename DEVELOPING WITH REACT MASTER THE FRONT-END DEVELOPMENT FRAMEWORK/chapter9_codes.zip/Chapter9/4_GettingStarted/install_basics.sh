#!/bin/bash
pnpm add -D vitest @testing-library/react @testing-library/user-event @testing-library/jest-dom msw
pnpm add -D playwright @axe-core/playwright

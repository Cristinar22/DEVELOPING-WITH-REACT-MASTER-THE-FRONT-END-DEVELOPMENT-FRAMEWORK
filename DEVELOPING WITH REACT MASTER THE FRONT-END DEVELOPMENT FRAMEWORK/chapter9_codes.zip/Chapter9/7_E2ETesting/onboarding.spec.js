import { test, expect } from '@playwright/test';

test('Onboarding wizard end-to-end', async ({ page }) => {
  await page.goto('/');
  await page.fill('input[placeholder="Name"]', 'Grace Hopper');
  await page.fill('input[placeholder="Email"]', 'grace@navy.mil');
  await page.fill('input[placeholder="Age"]', '34');
  await page.click('button:text("Next")');
  // ...repeat for steps
  await page.click('button:text("Submit")');
  await expect(page.locator('text=Submitted')).toBeVisible();
});

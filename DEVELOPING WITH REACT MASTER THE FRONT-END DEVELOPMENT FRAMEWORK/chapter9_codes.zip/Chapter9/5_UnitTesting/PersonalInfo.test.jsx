import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import PersonalInfo from "./PersonalInfo";

test("renders form and validates fields", async () => {
  render(<PersonalInfo onNext={jest.fn()} />);
  const next = screen.getByRole("button", { name: /next/i });
  expect(next).toBeDisabled();

  await userEvent.type(screen.getByPlaceholderText(/name/i), "Ada Lovelace");
  await userEvent.type(screen.getByPlaceholderText(/email/i), "ada@example.com");
  await userEvent.type(screen.getByPlaceholderText(/age/i), "30");

  expect(next).not.toBeDisabled();
});

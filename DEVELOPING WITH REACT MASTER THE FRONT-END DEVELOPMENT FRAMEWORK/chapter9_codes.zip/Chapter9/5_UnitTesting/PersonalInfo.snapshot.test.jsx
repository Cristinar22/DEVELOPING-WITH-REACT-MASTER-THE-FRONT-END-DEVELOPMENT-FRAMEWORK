import { render } from "@testing-library/react";
import PersonalInfo from "./PersonalInfo";

test("matches snapshot", () => {
  const { asFragment } = render(<PersonalInfo />);
  expect(asFragment()).toMatchSnapshot();
});

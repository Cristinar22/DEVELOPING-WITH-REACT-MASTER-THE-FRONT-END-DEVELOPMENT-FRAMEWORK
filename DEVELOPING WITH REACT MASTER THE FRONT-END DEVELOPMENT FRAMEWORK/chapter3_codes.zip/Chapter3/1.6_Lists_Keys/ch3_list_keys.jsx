{recipes.map(r => (
  <RecipeCard key={r.id} recipe={r} />
))}
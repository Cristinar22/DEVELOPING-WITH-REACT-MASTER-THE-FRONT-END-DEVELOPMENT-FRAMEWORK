function Pagination({ total, perPage, page, onPage }) {
  const pages = Math.ceil(total / perPage);
  return (
    <nav className="pagination">
      {Array.from({ length: pages }, (_, i) => i + 1).map(n => (
        <button
          key={n}
          className={n === page ? 'active' : ''}
          onClick={() => onPage(n)}
        >
          {n}
        </button>
      ))}
    </nav>
  );
}
function Avatar({ url, size = 48 }) {
  return <img src={url} width={size} height={size} />;
}
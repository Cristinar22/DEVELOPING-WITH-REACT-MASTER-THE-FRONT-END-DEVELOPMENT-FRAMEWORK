function Counter() {
  const [count, setCount] = useState(0);
  return (
    <Display value={count} onIncrement={() => setCount(c => c + 1)} />
  );
}
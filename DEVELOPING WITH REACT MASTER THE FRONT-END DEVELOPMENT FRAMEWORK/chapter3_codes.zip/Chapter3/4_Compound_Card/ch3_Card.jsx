import { createContext, useContext } from 'react';

function Card({ children, as: Comp = 'article', ...rest }) {
  return <Comp className="card" {...rest}>{children}</Comp>;
}

Card.Image = function CardImage({ src, alt }) {
  return <img src={src} alt={alt} />;
};

Card.Title = function CardTitle({ children }) {
  return <h3>{children}</h3>;
};

Card.Body = function CardBody({ children }) {
  return <p>{children}</p>;
};

export default Card;
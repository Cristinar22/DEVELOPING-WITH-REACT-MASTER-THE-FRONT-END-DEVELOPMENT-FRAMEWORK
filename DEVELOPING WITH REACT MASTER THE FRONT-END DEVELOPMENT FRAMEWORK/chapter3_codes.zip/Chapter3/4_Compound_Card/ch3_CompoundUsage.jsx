<Card onClick={() => open(recipe.id)}>
  <Card.Image src={recipe.image} alt={recipe.title} />
  <Card.Title>{recipe.title}</Card.Title>
  <Card.Body>
    Ready in {recipe.readyInMinutes} min • Serves {recipe.servings}
  </Card.Body>
</Card>
<GrandParent theme={theme}>
  <Parent theme={theme}>
    <Child theme={theme} />
  </Parent>
</GrandParent>
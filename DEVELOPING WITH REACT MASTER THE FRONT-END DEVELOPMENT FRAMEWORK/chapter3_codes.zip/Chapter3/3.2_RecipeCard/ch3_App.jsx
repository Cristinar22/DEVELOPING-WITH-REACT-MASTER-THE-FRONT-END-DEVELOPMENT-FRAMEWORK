import recipes from './data/recipes.json';
import RecipeCard from './components/RecipeCard';

export default function App() {
  const [page, setPage] = useState(1);
  const perPage = 6;
  const start = (page - 1) * perPage;
  const current = recipes.slice(start, start + perPage);

  return (
    <>
      <Pagination
        total={recipes.length}
        perPage={perPage}
        page={page}
        onPage={setPage}
      />
      <section className="grid">
        {current.map(r => (
          <RecipeCard key={r.id} recipe={r} />
        ))}
      </section>
    </>
  );
}
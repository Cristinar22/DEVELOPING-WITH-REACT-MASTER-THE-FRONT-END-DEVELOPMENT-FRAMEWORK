export default function RecipeCard({ recipe, onSelect }) {
  return (
    <article className="card" onClick={() => onSelect?.(recipe.id)}>
      <img src={recipe.image} alt={recipe.title} />
      <h3>{recipe.title}</h3>
      <p>
        Ready in {recipe.readyInMinutes} min • Serves {recipe.servings}
      </p>
    </article>
  );
}
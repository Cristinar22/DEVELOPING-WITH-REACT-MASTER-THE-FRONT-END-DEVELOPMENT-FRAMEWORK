const EmptyState = () => <p>No items yet.</p>;

function TodoList({ items }) {
  return items.length ? (
    <ul>{items.map(i => <li key={i.id}>{i.text}</li>)}</ul>
  ) : (
    <EmptyState />
  );
}
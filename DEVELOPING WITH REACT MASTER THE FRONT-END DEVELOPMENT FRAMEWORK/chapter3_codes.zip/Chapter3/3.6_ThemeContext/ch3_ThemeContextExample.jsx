import { createContext, useContext, useState } from 'react';

export const ThemeContext = createContext('light');

function App() {
  const [theme, setTheme] = useState('light');
  return (
    <ThemeContext.Provider value={theme}>
      …
    </ThemeContext.Provider>
  );
}

function RecipeCard({ recipe }) {
  const theme = useContext(ThemeContext);
  return (
    <article className={`card ${theme}`}>
      …
    </article>
  );
}
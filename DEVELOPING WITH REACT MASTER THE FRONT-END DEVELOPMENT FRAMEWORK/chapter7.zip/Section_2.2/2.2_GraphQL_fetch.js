fetch("/graphql", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    query: "{ recipes { id title description } }"
  })
})
  .then(res => res.json())
  .then(data => setRecipes(data.data.recipes));
import { useSelector, useDispatch } from "react-redux";
import { login, logout } from "./store/authSlice";

function AuthStatus() {
  const user = useSelector(state => state.auth.user);
  const dispatch = useDispatch();
  // ...login/logout logic
}
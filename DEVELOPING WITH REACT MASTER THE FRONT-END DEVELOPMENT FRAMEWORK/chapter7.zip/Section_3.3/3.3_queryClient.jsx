import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
const queryClient = new QueryClient();

root.render(
  <QueryClientProvider client={queryClient}>
    <App />
  </QueryClientProvider>
);
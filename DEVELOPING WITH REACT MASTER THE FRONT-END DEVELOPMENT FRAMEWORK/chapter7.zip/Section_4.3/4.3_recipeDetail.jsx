const { data: recipe } = useQuery({
  queryKey: ['recipe', id],
  queryFn: () => fetch(`http://localhost:4000/recipes/${id}`).then(r => r.json())
});
import { useMutation, useQueryClient } from '@tanstack/react-query';

function AddRecipe() {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: newRecipe =>
      fetch('http://localhost:4000/recipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRecipe)
      }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
    }
  });

  function handleAdd(recipe) {
    mutation.mutate(recipe);
  }
  // ...form etc.
}
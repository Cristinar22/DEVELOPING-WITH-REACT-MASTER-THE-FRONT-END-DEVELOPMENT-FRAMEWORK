const mutation = useMutation({
  mutationFn: ...,
  onMutate: async (newRecipe) => {
    await queryClient.cancelQueries({ queryKey: ['recipes'] });
    const previous = queryClient.getQueryData(['recipes']);
    queryClient.setQueryData(['recipes'], old => [...old, newRecipe]);
    return { previous };
  },
  onError: (err, newRecipe, context) => {
    queryClient.setQueryData(['recipes'], context.previous);
  },
  onSettled: () => {
    queryClient.invalidateQueries({ queryKey: ['recipes'] });
  }
});
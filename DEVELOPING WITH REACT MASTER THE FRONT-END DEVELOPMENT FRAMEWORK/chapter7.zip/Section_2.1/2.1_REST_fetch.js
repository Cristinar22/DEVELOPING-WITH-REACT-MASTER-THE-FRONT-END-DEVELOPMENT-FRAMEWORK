fetch("/api/recipes")
  .then(res => res.json())
  .then(data => setRecipes(data));
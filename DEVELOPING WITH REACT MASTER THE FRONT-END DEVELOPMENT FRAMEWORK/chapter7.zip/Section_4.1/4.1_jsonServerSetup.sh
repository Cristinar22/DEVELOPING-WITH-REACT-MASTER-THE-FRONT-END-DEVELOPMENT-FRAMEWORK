pnpm add -D json-server
echo '{ "recipes": [ { "id": "1", "title": "Pasta", "description": "Yum!" } ] }' > db.json
npx json-server --watch db.json --port 4000
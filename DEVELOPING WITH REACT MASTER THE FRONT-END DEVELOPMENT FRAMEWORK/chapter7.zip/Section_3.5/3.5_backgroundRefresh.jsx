useQuery({
  queryKey: ['recipes'],
  queryFn: ...,
  refetchInterval: 30000 // refresh every 30s
});
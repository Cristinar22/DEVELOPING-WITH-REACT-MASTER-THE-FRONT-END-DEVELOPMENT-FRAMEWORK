import { useQuery } from '@tanstack/react-query';

function RecipesList() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['recipes'],
    queryFn: () => fetch('/api/recipes').then(res => res.json())
  });

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Oops: {error.message}</div>;

  return (
    <ul>
      {data.map(recipe => (
        <li key={recipe.id}>{recipe.title}</li>
      ))}
    </ul>
  );
}
import React, { useState } from 'react';
import PersonalInfo from './6.3_Step1_PersonalInfo';
import JobDetails from './6.3_Step2_JobDetails';
import SkillsStep from './6.3_Step3_SkillsStep';
import Review from './Review';

function OnboardingWizard() {
  const [step, setStep] = useState(1);
  const [allData, setAllData] = useState({});
  function handleNext(data) {
    setAllData(prev => ({ ...prev, ...data }));
    setStep(step + 1);
  }
  function handleSubmit() {
    alert("Submitted!");
  }
  return (
    <>
      {step === 1 && <PersonalInfo onNext={handleNext} />}
      {step === 2 && <JobDetails onNext={handleNext} />}
      {step === 3 && <SkillsStep onNext={handleNext} />}
      {step === 4 && <Review data={allData} onSubmit={handleSubmit} />}
    </>
  );
}

export default OnboardingWizard;
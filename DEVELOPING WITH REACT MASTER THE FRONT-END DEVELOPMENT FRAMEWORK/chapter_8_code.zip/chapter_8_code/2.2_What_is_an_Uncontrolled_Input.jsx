import React, { useRef } from 'react';

function UncontrolledInput() {
  const ref = useRef();
  return (
    <>
      <input ref={ref} />
      <button onClick={() => alert(ref.current.value)}>Show Value</button>
    </>
  );
}

export default UncontrolledInput;
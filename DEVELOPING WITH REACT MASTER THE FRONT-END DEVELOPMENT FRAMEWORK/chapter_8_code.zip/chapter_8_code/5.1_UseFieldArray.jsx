import React from 'react';
import { useForm, useFieldArray } from 'react-hook-form';

function SkillsForm() {
  const { register, control, handleSubmit } = useForm({
    defaultValues: { skills: [""] }
  });
  const { fields, append, remove } = useFieldArray({ control, name: "skills" });

  function onSubmit(data) {
    console.log(data);
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {fields.map((field, index) => (
        <div key={field.id}>
          <input {...register(`skills.${index}`)} />
          <button type="button" onClick={() => remove(index)}>Remove</button>
        </div>
      ))}
      <button type="button" onClick={() => append("")}>Add Skill</button>
      <button type="submit">Submit</button>
    </form>
  );
}

export default SkillsForm;
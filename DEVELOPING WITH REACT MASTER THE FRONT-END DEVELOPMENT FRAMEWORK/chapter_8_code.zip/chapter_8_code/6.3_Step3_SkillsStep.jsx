import React from 'react';
import { useForm, useFieldArray } from 'react-hook-form';

function SkillsStep({ onNext, defaultValues }) {
  const { register, handleSubmit, control } = useForm({ defaultValues });
  const { fields, append, remove } = useFieldArray({ control, name: "skills" });
  function onSubmit(data) { onNext(data); }
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {fields.map((field, idx) => (
        <div key={field.id}>
          <input {...register(`skills.${idx}`)} placeholder="Skill" />
          <button type="button" onClick={() => remove(idx)}>Remove</button>
        </div>
      ))}
      <button type="button" onClick={() => append("")}>Add Skill</button>
      <button type="submit">Next</button>
    </form>
  );
}

export default SkillsStep;
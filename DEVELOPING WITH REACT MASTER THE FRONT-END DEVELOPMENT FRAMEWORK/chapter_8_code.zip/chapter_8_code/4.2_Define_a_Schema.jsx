import * as yup from 'yup';

const schema = yup.object().shape({
  name: yup.string().required("Name is required"),
  age: yup.number().required().min(18, "Must be at least 18"),
  email: yup.string().email("Invalid email").required(),
});

export default schema;
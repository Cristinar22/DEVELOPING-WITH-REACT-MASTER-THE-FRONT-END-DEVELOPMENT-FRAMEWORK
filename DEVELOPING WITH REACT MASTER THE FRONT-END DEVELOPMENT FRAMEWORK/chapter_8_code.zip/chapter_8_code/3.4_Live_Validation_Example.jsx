import React from 'react';
import { useForm } from 'react-hook-form';

function LiveValidationForm() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  function onSubmit(data) {
    console.log(data);
  }
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input
        {...register("email", { required: "Email required" })}
        placeholder="Email"
      />
      {errors.email && <p>{errors.email.message}</p>}
      <button type="submit">Submit</button>
    </form>
  );
}

export default LiveValidationForm;
pnpm add yup @hookform/resolvers
# or for Valibot:
pnpm add valibot @hookform/resolvers
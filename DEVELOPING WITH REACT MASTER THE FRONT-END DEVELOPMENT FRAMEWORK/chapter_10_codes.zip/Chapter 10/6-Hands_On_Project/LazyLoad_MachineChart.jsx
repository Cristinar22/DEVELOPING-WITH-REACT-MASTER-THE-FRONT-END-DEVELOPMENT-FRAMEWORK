import { lazy, Suspense } from "react";
const MachineChart = lazy(() => import("./MachineChart"));

<Suspense fallback={<Spinner />}>
  <MachineChart />
</Suspense>
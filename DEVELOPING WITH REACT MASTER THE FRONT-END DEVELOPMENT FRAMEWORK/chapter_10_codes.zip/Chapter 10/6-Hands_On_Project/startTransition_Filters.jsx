import { useState, startTransition } from "react";
function FilterPanel() {
  const [filter, setFilter] = useState("");
  const [results, setResults] = useState([]);
  function handleFilter(e) {
    startTransition(() => {
      setFilter(e.target.value);
      setResults(expensiveFilter(e.target.value));
    });
  }
  return <input onChange={handleFilter} />;
}
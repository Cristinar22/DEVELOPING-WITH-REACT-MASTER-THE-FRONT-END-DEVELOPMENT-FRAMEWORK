function ChartLink() {
  function prefetch() {
    import("./MachineChart");
  }
  return (
    <a onMouseEnter={prefetch} href="/charts/machine">
      Machine Analytics
    </a>
  );
}
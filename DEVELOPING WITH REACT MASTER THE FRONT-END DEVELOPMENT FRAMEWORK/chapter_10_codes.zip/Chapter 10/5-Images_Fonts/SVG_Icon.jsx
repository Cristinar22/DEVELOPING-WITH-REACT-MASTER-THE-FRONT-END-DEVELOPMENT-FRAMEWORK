const CheckIcon = () => (
  <svg width="24" height="24" aria-hidden="true" focusable="false">
    <path d="..." />
  </svg>
);
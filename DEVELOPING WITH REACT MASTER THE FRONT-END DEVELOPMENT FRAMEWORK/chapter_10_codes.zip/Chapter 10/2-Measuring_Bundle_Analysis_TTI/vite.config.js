import { visualizer } from "rollup-plugin-visualizer";
export default defineConfig({
  plugins: [visualizer()]
});
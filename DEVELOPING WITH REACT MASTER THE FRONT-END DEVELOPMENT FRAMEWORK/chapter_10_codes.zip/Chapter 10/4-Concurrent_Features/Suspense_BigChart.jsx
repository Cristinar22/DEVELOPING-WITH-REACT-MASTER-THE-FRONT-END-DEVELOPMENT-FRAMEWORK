import { lazy, Suspense } from "react";
const BigChart = lazy(() => import("./BigChart"));

<Suspense fallback={<Spinner />}>
  <BigChart />
</Suspense>
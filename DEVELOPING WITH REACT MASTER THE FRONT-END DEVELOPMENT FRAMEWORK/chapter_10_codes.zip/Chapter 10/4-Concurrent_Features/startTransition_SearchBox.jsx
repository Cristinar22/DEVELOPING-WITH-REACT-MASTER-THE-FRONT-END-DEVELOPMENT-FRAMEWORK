import { useState, startTransition } from "react";
function SearchBox() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  function handleChange(e) {
    setQuery(e.target.value);
    startTransition(() => {
      setResults(heavySearch(e.target.value));
    });
  }
  return <input value={query} onChange={handleChange} />;
}
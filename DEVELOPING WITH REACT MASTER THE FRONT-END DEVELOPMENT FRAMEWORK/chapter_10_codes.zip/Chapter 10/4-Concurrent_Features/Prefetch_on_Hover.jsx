const Chart = lazy(() => import("./Chart"));
function PrefetchLink() {
  function prefetch() {
    import("./Chart");
  }
  return <button onMouseEnter={prefetch}>View Chart</button>;
}
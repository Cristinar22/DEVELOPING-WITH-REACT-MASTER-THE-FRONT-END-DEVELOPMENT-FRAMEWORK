import { useState, useEffect } from 'react';

function ThemeToggle() {
  const [dark, setDark] = useState(
    () => window.matchMedia('(prefers-color-scheme: dark)').matches
  );
  useEffect(
    () =>
      document.documentElement.setAttribute(
        'data-theme',
        dark ? 'dark' : 'light'
      ),
    [dark]
  );
  return (
    <button onClick={() => setDark(!dark)}>
      {dark ? '🌙 Dark' : '☀️ Light'}
    </button>
  );
}

export default ThemeToggle;
import { useState, useEffect } from 'react';

function useLocalStorage(key, fallback) {
  const [state, setState] = useState(() =>
    JSON.parse(localStorage.getItem(key)) ?? fallback
  );
  useEffect(() => localStorage.setItem(key, JSON.stringify(state)), [state]);
  return [state, setState];
}

export default useLocalStorage;
#!/bin/bash
git init
git add .
git commit -m "feat: hello-react todo" 
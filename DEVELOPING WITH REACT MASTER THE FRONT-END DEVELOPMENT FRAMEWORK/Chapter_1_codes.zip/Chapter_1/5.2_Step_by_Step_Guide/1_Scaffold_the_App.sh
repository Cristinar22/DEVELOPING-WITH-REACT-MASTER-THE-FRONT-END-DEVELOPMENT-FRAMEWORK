#!/bin/bash
pnpm create vite hello-react --template react
cd hello-react
pnpm install
pnpm dev
# Open http://localhost:5173
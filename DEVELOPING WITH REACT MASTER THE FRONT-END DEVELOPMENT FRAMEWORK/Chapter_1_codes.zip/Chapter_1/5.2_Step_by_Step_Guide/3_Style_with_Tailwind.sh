#!/bin/bash
pnpm add -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
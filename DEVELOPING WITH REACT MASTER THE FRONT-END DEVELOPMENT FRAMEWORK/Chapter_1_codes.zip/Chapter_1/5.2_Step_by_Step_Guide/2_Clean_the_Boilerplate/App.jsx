import { useState } from 'react';
import './App.css';

export default function App() {
  const [items, setItems] = useState([]);
  const [text, setText] = useState('');

  function addItem(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setItems([...items, { id: crypto.randomUUID(), text }]);
    setText('');
  }

  function remove(id) {
    setItems(items.filter(i => i.id !== id));
  }

  return (
    <div className="wrapper">
      <h1>My To-Do</h1>
      <form onSubmit={addItem}>
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Add a task"
        />
        <button>Add</button>
      </form>
      <ul>
        {items.map(i => (
          <li key={i.id} onClick={() => remove(i.id)}>
            {i.text}
          </li>
        ))}
      </ul>
    </div>
  );
}
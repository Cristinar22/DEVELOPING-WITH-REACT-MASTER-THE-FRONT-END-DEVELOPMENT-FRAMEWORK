// Mutate: find node, change class
button.classList.add('active');
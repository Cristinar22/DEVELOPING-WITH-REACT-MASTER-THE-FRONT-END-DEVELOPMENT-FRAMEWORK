import { useState } from "react";

function ControlledInput() {
  const [email, setEmail] = useState("");

  return (
    <input
      value={email}
      onChange={e => setEmail(e.target.value)}
      placeholder="Enter your email"
    />
  );
}

export default ControlledInput;
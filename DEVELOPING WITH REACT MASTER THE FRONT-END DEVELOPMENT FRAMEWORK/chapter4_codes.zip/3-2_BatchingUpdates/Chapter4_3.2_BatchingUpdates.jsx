// Demonstrating React's automatic batching
import { useState } from "react";

function BatchExample() {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);

  function updateBoth() {
    setA(a + 1);
    setB(b + 1);
    // React will batch these updates into a single re-render
  }

  return (
    <div>
      <p>A: {a}</p>
      <p>B: {b}</p>
      <button onClick={updateBoth}>Update Both</button>
    </div>
  );
}

export default BatchExample;
import { startTransition, useState } from "react";

function SearchBox() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  function handleChange(e) {
    setQuery(e.target.value);
    startTransition(() => {
      // Simulate a heavy search
      setResults(searchDb(e.target.value));
    });
  }

  return (
    <input
      value={query}
      onChange={handleChange}
      placeholder="Search..."
    />
  );
}

export default SearchBox;

// Helper function for simulation
function searchDb(query) {
  // simulate search logic
  return [];
}
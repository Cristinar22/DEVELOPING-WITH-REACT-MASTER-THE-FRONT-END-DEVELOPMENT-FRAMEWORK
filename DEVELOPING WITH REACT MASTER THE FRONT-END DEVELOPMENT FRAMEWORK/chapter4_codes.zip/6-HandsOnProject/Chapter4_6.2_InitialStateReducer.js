// Step 1: Initial State and Reducer
export const initialState = {
  name: "",
  email: "",
  message: "",
  submitted: false,
};

export function reducer(state, action) {
  switch (action.type) {
    case "SET_FIELD":
      return { ...state, [action.field]: action.value };
    case "SUBMIT":
      return { ...initialState, submitted: true };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}
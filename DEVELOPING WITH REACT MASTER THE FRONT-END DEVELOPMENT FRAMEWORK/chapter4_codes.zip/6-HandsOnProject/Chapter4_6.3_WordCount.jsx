function WordCount({ value }) {
  const words = value.trim().split(/\s+/).filter(Boolean).length;
  return <span className="word-count">{words} words</span>;
}

export default WordCount;
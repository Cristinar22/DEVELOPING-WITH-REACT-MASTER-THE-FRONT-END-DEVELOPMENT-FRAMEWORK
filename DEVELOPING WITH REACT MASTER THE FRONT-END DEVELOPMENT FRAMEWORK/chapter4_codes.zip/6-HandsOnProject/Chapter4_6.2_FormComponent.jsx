import { useReducer } from "react";
import { initialState, reducer } from "./Chapter4_6.2_InitialStateReducer";

export default function FeedbackForm() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const valid =
    state.name.trim().length > 1 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.email) &&
    state.message.trim().length > 5;

  function onChange(e) {
    dispatch({ type: "SET_FIELD", field: e.target.name, value: e.target.value });
  }

  function onSubmit(e) {
    e.preventDefault();
    if (valid) {
      dispatch({ type: "SUBMIT" });
    }
  }

  return (
    <form onSubmit={onSubmit} className="feedback-form">
      <label>
        Name
        <input name="name" value={state.name} onChange={onChange} required />
      </label>
      <label>
        Email
        <input name="email" value={state.email} onChange={onChange} required />
      </label>
      <label>
        Message
        <textarea name="message" value={state.message} onChange={onChange} required />
        <WordCount value={state.message} />
      </label>
      <button type="submit" disabled={!valid}>Submit</button>
      {state.submitted && <div className="success">Thank you!</div>}
    </form>
  );
}

// Remember to import WordCount component
import { useState, useCallback } from "react";

function Parent() {
  const [value, setValue] = useState(0);

  const handleClick = useCallback(() => setValue(v => v + 1), []);

  return <Child onClick={handleClick} />;
}

function Child({ onClick }) {
  return <button onClick={onClick}>Click me</button>;
}

export { Parent, Child };
import { useState, useEffect } from "react";

function CounterWithEffect() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    // Correct: Only runs when count changes
    setCount(c => c + 1);
  }, [count]);

  return <p>Count: {count}</p>;
}

export default CounterWithEffect;
import { useReducer } from "react";

const initialState = { name: "", email: "", feedback: "" };

function reducer(state, action) {
  switch (action.type) {
    case "FIELD":
      return { ...state, [action.field]: action.value };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}

function FeedbackForm() {
  const [state, dispatch] = useReducer(reducer, initialState);

  function handleChange(e) {
    dispatch({ type: "FIELD", field: e.target.name, value: e.target.value });
  }
  function handleReset() {
    dispatch({ type: "RESET" });
  }

  return (
    <form>
      <input name="name" value={state.name} onChange={handleChange} />
      <input name="email" value={state.email} onChange={handleChange} />
      <textarea name="feedback" value={state.feedback} onChange={handleChange} />
      <button type="button" onClick={handleReset}>Clear</button>
    </form>
  );
}

export default FeedbackForm;
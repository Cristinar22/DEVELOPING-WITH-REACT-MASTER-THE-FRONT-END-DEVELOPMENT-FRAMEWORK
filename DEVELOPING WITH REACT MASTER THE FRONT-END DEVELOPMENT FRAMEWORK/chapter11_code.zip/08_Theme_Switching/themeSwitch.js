js
export function switchTheme(theme) {
  const root = document.documentElement;
  Object.entries(theme.tokens).forEach(([key, value]) => {
    root.style.setProperty(`--${key}`, value);
  });
}

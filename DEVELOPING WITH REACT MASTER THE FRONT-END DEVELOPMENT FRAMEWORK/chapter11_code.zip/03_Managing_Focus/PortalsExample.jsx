jsx
import React from "react";
import { createPortal } from "react-dom";

function Modal() {
  return createPortal(
    <div role="dialog" aria-modal="true">
      {/* Modal content */}
    </div>,
    document.body
  );
}

export default Modal;

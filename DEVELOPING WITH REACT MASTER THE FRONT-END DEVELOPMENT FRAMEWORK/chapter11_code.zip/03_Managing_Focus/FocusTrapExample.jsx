bash
pnpm add focus-trap-react
jsx

import React from "react";
import FocusTrap from "focus-trap-react";

function Modal({ open, onClose }) {
  if (!open) return null;
  return (
    <FocusTrap>
      <div role="dialog" aria-modal="true">
        <button onClick={onClose}>Close</button>
        {/* Modal content */}
      </div>
    </FocusTrap>
  );
}

export default Modal;

bash
npx sb init
pnpm add @storybook/addon-a11y

jsx
import React from "react";
import { I18nextProvider, useTranslation } from "react-i18next";
import i18n from "./i18n"; // your config

function OnboardingWizard() {
  const { t } = useTranslation();
  return (
    <div dir={i18n.dir()}>
      <h1>{t('welcome')}</h1>
      {/* Wizard steps */}
    </div>
  );
}

export default OnboardingWizard;

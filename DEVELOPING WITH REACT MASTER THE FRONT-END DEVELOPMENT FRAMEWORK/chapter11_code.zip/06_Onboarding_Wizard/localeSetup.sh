bash
pnpm add react-i18next i18next
